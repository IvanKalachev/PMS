﻿<%@ Application Codebehind="Global.asax.cs" Inherits="MVC3RazorNhibernate.MvcApplication" Language="C#" %>
